import { Category } from "./types";

export const categories: Category[] = [
  {
    id: "shopping",
    name: "Shopping",
    image: "https://images.unsplash.com/photo-1607083206869-4c7672e72a8a?q=80&w=800",
  },
  {
    id: "gaming",
    name: "Gaming",
    image: "https://images.unsplash.com/photo-1612287230202-1ff1d85d1bdf?q=80&w=800",
  },
  {
    id: "music",
    name: "Music",
    image: "https://images.unsplash.com/photo-1511671782779-c97d3d27a1d4?q=80&w=800",
  },
  {
    id: "entertainment",
    name: "Entertainment",
    image: "https://images.unsplash.com/photo-1585699324551-f6c309eedeca?q=80&w=800",
  },
  {
    id: "virtual",
    name: "Virtual Cards",
    image: "https://images.unsplash.com/photo-1563013544-824ae1b704d3?q=80&w=800",
  },
  {
    id: "crypto",
    name: "Crypto",
    image: "https://images.unsplash.com/photo-1621761191319-c6fb62004040?q=80&w=800",
  },
];

// Empty arrays for gift cards and promotions as they will be managed through admin
export const giftCards = [];
export const promotions = [];