import { GiftCard } from "@/components/gift-card";
import { PromotionSlider } from "@/components/promotion-slider";
import { categories, promotions } from "@/lib/data";

export default function Home() {
  const activePromotions = promotions.filter(promo => promo.active);

  return (
    <div className="container py-8 space-y-12">
      <PromotionSlider promotions={activePromotions} />
      
      <section className="space-y-8">
        <div className="text-center space-y-2">
          <h1 className="text-4xl font-bold tracking-tight">Popular Gift Cards</h1>
          <p className="text-muted-foreground">Discover our most popular digital gift cards</p>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
          {/* Gift cards will be populated from admin panel */}
        </div>
      </section>

      <section className="space-y-8">
        <div className="text-center space-y-2">
          <h2 className="text-3xl font-bold tracking-tight">Browse Categories</h2>
          <p className="text-muted-foreground">Find the perfect gift card by category</p>
        </div>

        <div className="grid grid-cols-2 md:grid-cols-3 lg:grid-cols-6 gap-4">
          {categories.map((category) => (
            <a
              key={category.id}
              href={`/category/${category.id}`}
              className="group relative aspect-square overflow-hidden rounded-lg bg-muted"
            >
              <img
                src={category.image}
                alt={category.name}
                className="object-cover w-full h-full transition-transform group-hover:scale-105"
              />
              <div className="absolute inset-0 bg-black/50 flex items-center justify-center">
                <h3 className="text-lg font-semibold text-white">{category.name}</h3>
              </div>
            </a>
          ))}
        </div>
      </section>
    </div>
  );
}